import { Component } from '@angular/core';

@Component({
  selector: 'app-orders-page',
  imports: [],
  templateUrl: './orders-page.component.html',
  styleUrl: './orders-page.component.scss'
})
export class OrdersPageComponent {

}
