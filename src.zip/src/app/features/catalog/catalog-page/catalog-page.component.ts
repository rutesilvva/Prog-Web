import { Component } from '@angular/core';

@Component({
  selector: 'app-catalog-page',
  imports: [],
  templateUrl: './catalog-page.component.html',
  styleUrl: './catalog-page.component.scss'
})
export class CatalogPageComponent {

}
