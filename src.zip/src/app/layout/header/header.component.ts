import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../../core/services/cart.service';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  catOpen = false;
  totalQty = 0;

  categories = [
    { label: 'IA e Machine Learning', code: 'ia-ml' },
    { label: 'Ciência de Dados', code: 'data' },
    { label: 'Programação', code: 'prog' },
    { label: 'DevOps e Nuvem', code: 'devops' },
    { label: 'Redes e Segurança', code: 'netsec' },
    { label: 'Sistemas e Arquitetura', code: 'arch' },
    { label: 'Banco de Dados', code: 'db' }
  ];

  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.cartService.cartItems.subscribe(items => {
      this.totalQty = items.reduce((sum, i) => sum + i.quantity, 0);
    });
  }

  closeCats() {
    this.catOpen = false;
  }
}